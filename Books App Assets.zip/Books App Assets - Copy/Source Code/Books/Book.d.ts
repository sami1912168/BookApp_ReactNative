type Book = {
  image: string;
  title: string;
  authors: string[];
  isbn: string;
};
